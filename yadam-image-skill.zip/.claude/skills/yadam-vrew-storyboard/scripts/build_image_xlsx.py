#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
블록 파일 + 스토리보드 xlsx → 이미지용 스토리보드 xlsx.

블록 파일(텍스트, 구분자 '|') 한 줄이 이미지 하나다:
  이미지번호|시작클립|끝클립|등장인물|프롬프트|켄번즈
  1|1|2|Yunssi_Buin|Korean manhwa style illustration ...|zoom-in
첫 줄이 '이미지번호' 로 시작하면 헤더로 보고 건너뛴다. 프롬프트 안에 '|' 를 쓰면
열이 갈라지므로 프롬프트에는 '|' 를 넣지 않는다.

하는 일:
  1) 블록이 클립을 1번부터 마지막까지 빈틈·겹침 없이 덮는지, 이미지 번호가 1부터 연속인지 검사
  2) 프롬프트·등장인물·켄번즈가 지침(references/지침.md)의 기계 검사 가능 규칙을 지키는지 검사
  3) 통과하면 스토리보드 xlsx 를 읽어 이미지 번호(모든 행) / 등장인물·프롬프트·켄번즈(블록 첫 행만)
     를 채운 이미지용 xlsx 를 쓴다
  검사에 걸리면 xlsx 를 쓰지 않고 오류 목록을 출력하고 종료 코드 1 을 돌려준다.
  (--force 를 주면 오류가 있어도 쓴다. 경고(warning)는 쓰기를 막지 않는다.)

사용:
  python build_image_xlsx.py <스토리보드.xlsx> <블록.txt> [-o 출력.xlsx] [--force]
기본 출력: <스토리보드.xlsx 이름>_이미지용.xlsx (같은 폴더)
"""
import argparse
import re
import sys
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

HEADERS = ["클립번호", "시작시간", "끝시간", "대본", "이미지 번호", "등장인물", "프롬프트", "켄번즈"]
COL_WIDTHS = {"A": 10, "B": 16, "C": 16, "D": 50, "E": 12, "F": 20, "G": 50, "H": 12}
HEADER_FILL = "4472C4"
FONT_NAME = "Arial"

KEN_BURNS = {"top-to-bottom", "bottom-to-top", "left-to-right", "right-to-left", "zoom-in", "zoom-out", "none"}
STYLE_PREFIX = "Korean manhwa style illustration with soft anime illustration, clean line, flat gentle shading"
PERSON_TAIL = "no text, no watermark, no modern sandals, no flip-flops, no slippers"
BG_TAIL = "no text, no watermark"
FRAME_FILL = ("filling frame", "filling entire frame", "filling the frame", "extending edge to edge",
              "throughout composition", "throughout the composition", "no empty space")

# 지침 §5 절대 금지 표현 — 걸리면 오류
FORBIDDEN = {
    "신발(sandals 계열)": r"\b(straw sandals|thong sandals|flip-flop|slipper|open-toe|bare toes|sneakers)\b",
    "유혈/부상": r"\b(blood|bleeding|bloodied|wound|wounded|bruise|bruised|scar|injury|injured|gash)\b",
    # 'striking' 은 지침 §5 노년 남성 키워드(dignified and striking)로도 쓰이므로 동사 문맥일 때만 잡는다
    "폭력 동작": r"\b(striking (him|her|them|it|the|a|an|at|down|across|with)|hitting|slapping|punching|beating|whipping|kicking|flogging|being tortured|being flogged|being beaten|knocked down)\b",
    "얼굴색 묘사": r"\b(pale (face|skin|complexion)|red face|red-faced|flushed|blushing|ashen|rosy cheeks|fair skin|bloodless|reddened|ruddy|white with (fear|shock))\b",
    "기술 키워드": r"\b(8k|4k|hdr|realistic|photorealistic|hyper-realistic)\b",
    "카메라 구도": r"\b(panoramic view|wide shot|cinematic ratio)\b",
    # 'showing/looking at' 은 프롬프트 첫머리(주체 자리)에 올 때만 문제다. 'smile showing teeth' 같은 감정 사전 표현은 허용
    "여백 유발 표현": r"^(a |an )?(close |wide |panoramic )?view of|^(looking at|showing)\b|\b(clear focus|clean pen lines)\b",
    "궁중 요소": r"\b(dragon embroidery|gold crown|royal (garments|robe|robes)|gonryongpo|ikseongwan)\b",
}
# 텍스트를 부르는 말하기 동사 — 이미지에 글자가 생기므로 경고
SPEECH = r"\b(speaking|talking|telling|explaining|describing|saying|asking|answering|shouting words|yelling words)\b"
GROUP_TAGS = {"villagers", "crowd", "soldiers", "servants", "ministers", "guards", "people", "officials"}


def parse_blocks(path: Path) -> list[dict]:
    blocks = []
    with path.open(encoding="utf-8-sig") as f:
        for ln, raw in enumerate(f, start=1):
            line = raw.rstrip("\r\n")
            if not line.strip():
                continue
            if ln == 1 and line.startswith("이미지번호"):
                continue
            parts = line.split("|")
            if len(parts) != 6:
                raise SystemExit(f"[블록파일 {ln}행] 열이 6개가 아닙니다({len(parts)}개). 프롬프트 안의 '|' 를 확인하세요.")
            img, s, e, chars, prompt, kb = [p.strip() for p in parts]
            try:
                blocks.append({"line": ln, "img": int(img), "start": int(s), "end": int(e),
                               "chars": chars, "prompt": prompt, "kb": kb})
            except ValueError:
                raise SystemExit(f"[블록파일 {ln}행] 이미지번호/시작클립/끝클립은 정수여야 합니다: {line[:80]}")
    if not blocks:
        raise SystemExit("블록이 하나도 없습니다.")
    return blocks


def validate(blocks: list[dict], n_clips: int) -> tuple[list[str], list[str]]:
    errors, warnings = [], []

    # 1) 번호·덮음 검사
    for i, b in enumerate(blocks, start=1):
        if b["img"] != i:
            errors.append(f"[이미지 {b['img']}] 이미지 번호가 연속이 아닙니다 (기대값 {i}).")
    expect = 1
    for b in blocks:
        if b["start"] != expect:
            errors.append(f"[이미지 {b['img']}] 시작클립 {b['start']} — 기대값 {expect} (빈틈 또는 겹침).")
        if b["end"] < b["start"]:
            errors.append(f"[이미지 {b['img']}] 끝클립({b['end']})이 시작클립({b['start']})보다 앞섭니다.")
        expect = b["end"] + 1
    if blocks[-1]["end"] != n_clips:
        errors.append(f"마지막 블록의 끝클립이 {blocks[-1]['end']} — 스토리보드 클립 수는 {n_clips}.")

    # 2) 켄번즈
    for b in blocks:
        if b["kb"] not in KEN_BURNS:
            errors.append(f"[이미지 {b['img']}] 켄번즈 값 '{b['kb']}' 은 허용 목록에 없습니다.")
    if blocks[-1]["kb"] != "none":
        errors.append(f"마지막 블록(이미지 {blocks[-1]['img']})의 켄번즈는 반드시 none 이어야 합니다.")

    # 3) 등장인물·프롬프트
    for b in blocks:
        tag = f"[이미지 {b['img']}]"
        p = b["prompt"]
        low = p.lower()
        if not p:
            errors.append(f"{tag} 프롬프트가 비어 있습니다.")
            continue
        if "\n" in p or "\r" in p:
            errors.append(f"{tag} 프롬프트에 줄바꿈이 있습니다.")
        if not p.startswith(STYLE_PREFIX):
            errors.append(f"{tag} 프롬프트가 고정 스타일 문구로 시작하지 않습니다.")
        names = [c.strip() for c in b["chars"].split(",") if c.strip()] if b["chars"] else []
        for n in names:
            if " " in n:
                errors.append(f"{tag} 등장인물 '{n}' 에 공백이 있습니다 → 언더바(_)로 바꾸세요.")
            if not re.fullmatch(r"[A-Za-z0-9_]+", n):
                errors.append(f"{tag} 등장인물 '{n}' 은 영문·숫자·언더바만 허용됩니다.")
        has_person = bool(names)
        if has_person:
            if not low.endswith(PERSON_TAIL):
                errors.append(f"{tag} 인물 프롬프트는 '{PERSON_TAIL}' 로 끝나야 합니다.")
            if "wearing" not in low:
                errors.append(f"{tag} 인물 프롬프트에 'wearing ...' 의상 묘사가 없습니다.")
        else:
            if not low.endswith(BG_TAIL) and not low.endswith(PERSON_TAIL):
                errors.append(f"{tag} 배경 프롬프트는 '{BG_TAIL}' 로 끝나야 합니다.")
        if not any(k in low for k in FRAME_FILL):
            errors.append(f"{tag} 프레임 채우기 문구(filling frame 등)가 없습니다.")
        # sandals: 'no modern sandals' 꼬리 외의 모든 'sandal' 은 금지
        stripped = low.replace("no modern sandals", "")
        if "sandal" in stripped:
            errors.append(f"{tag} 'sandals' 단어가 꼬리 문구 밖에서 쓰였습니다 → closed woven straw jipsin shoes 등으로 바꾸세요.")
        if "jipsin" in low and "closed woven straw jipsin shoes" not in low and "closed woven hemp" not in low:
            errors.append(f"{tag} 짚신은 'closed woven straw jipsin shoes' 표기를 써야 합니다.")
        if "taesahye" in low and "upturned toes" not in low:
            errors.append(f"{tag} 태사혜는 'with upturned toes' 를 함께 써야 합니다.")
        body = low[len(STYLE_PREFIX):] if low.startswith(STYLE_PREFIX.lower()) else low
        body_wo_tail = body.replace(PERSON_TAIL, "").replace(BG_TAIL, "").strip(" ,.")
        for label, rx in FORBIDDEN.items():
            m = re.search(rx, body_wo_tail)
            if m:
                errors.append(f"{tag} 금지 표현({label}): '{m.group(0)}'")
        m = re.search(SPEECH, body_wo_tail)
        if m:
            warnings.append(f"{tag} 말하기 동사 '{m.group(0)}' — 표정·제스처·시선으로 바꾸는 편이 안전합니다.")
        if has_person and len(p) < 250:
            warnings.append(f"{tag} 인물 프롬프트가 짧습니다({len(p)}자). 감정(표정+제스처+자세)과 배경 디테일을 확인하세요.")
    return errors, warnings


def write_xlsx(sb_path: Path, blocks: list[dict], out_path: Path) -> None:
    wb = load_workbook(sb_path)
    ws = wb.active
    header = [c.value for c in ws[1]]
    if header[:4] != HEADERS[:4]:
        raise SystemExit(f"스토리보드 헤더가 다릅니다: {header}")
    for i, h in enumerate(HEADERS, start=1):
        ws.cell(row=1, column=i, value=h)

    by_clip = {}
    for b in blocks:
        for c in range(b["start"], b["end"] + 1):
            by_clip[c] = (b, c == b["start"])

    thin = Side(style="thin")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    center_cols = {1, 2, 3, 5, 8}
    wrap_cols = {4, 7}

    for cell in ws[1]:
        cell.font = Font(name=FONT_NAME, size=11, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=HEADER_FILL)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border

    for row in ws.iter_rows(min_row=2, max_col=8):
        clip_no = row[0].value
        try:
            clip_no = int(clip_no)
        except (TypeError, ValueError):
            continue
        b, first = by_clip.get(clip_no, (None, False))
        if b is not None:
            row[4].value = b["img"]
            row[5].value = b["chars"] if first else None
            row[6].value = b["prompt"] if first else None
            row[7].value = b["kb"] if first else None
        for idx, cell in enumerate(row, start=1):
            cell.font = Font(name=FONT_NAME, size=11)
            cell.border = border
            cell.alignment = Alignment(
                horizontal="center" if idx in center_cols else None,
                vertical="center",
                wrap_text=idx in wrap_cols,
            )
    for col, width in COL_WIDTHS.items():
        ws.column_dimensions[col].width = width
    ws.freeze_panes = "A2"
    wb.save(out_path)


def main() -> None:
    ap = argparse.ArgumentParser(description="블록 파일 → 이미지용 스토리보드 xlsx")
    ap.add_argument("storyboard", help="스토리보드 xlsx (vrew_to_storyboard.py 출력)")
    ap.add_argument("blocks", help="블록 파일 txt (이미지번호|시작클립|끝클립|등장인물|프롬프트|켄번즈)")
    ap.add_argument("-o", "--output", help="출력 xlsx (기본: <스토리보드>_이미지용.xlsx)")
    ap.add_argument("--force", action="store_true", help="오류가 있어도 xlsx 를 쓴다")
    args = ap.parse_args()
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    sb_path = Path(args.storyboard)
    out_path = Path(args.output) if args.output else sb_path.with_name(sb_path.stem + "_이미지용.xlsx")
    ws = load_workbook(sb_path, read_only=True).active
    n_clips = sum(1 for r in ws.iter_rows(min_row=2, max_col=1, values_only=True) if r[0] is not None)

    blocks = parse_blocks(Path(args.blocks))
    errors, warnings = validate(blocks, n_clips)
    for w in warnings:
        print("경고:", w)
    if errors:
        for e in errors:
            print("오류:", e)
        print(f"\n오류 {len(errors)}건. 블록 파일을 고친 뒤 다시 실행하세요.")
        if not args.force:
            sys.exit(1)
        print("--force: 오류가 있지만 파일을 씁니다.")
    write_xlsx(sb_path, blocks, out_path)
    people = sorted({c.strip() for b in blocks for c in b["chars"].split(",") if c.strip()})
    named = [p for p in people if p.lower() not in GROUP_TAGS]
    print(f"[완료] {out_path}  (이미지 {len(blocks)}개 / 클립 {n_clips}개, 경고 {len(warnings)}건)")
    print(f"[등장인물] {', '.join(people)}")
    print(f"[턴어라운드 필요 인물] {', '.join(named)}  (무리 태그 제외)")


if __name__ == "__main__":
    main()
