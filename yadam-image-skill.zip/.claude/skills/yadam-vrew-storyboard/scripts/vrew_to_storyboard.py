#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Vrew 프로젝트(.vrew) → 스토리보드 엑셀(.xlsx) 변환기.

.vrew 는 zip 이고 안에 project.json 이 있다. transcript.clips 를 순서대로 읽어
클립번호 / 시작시간 / 끝시간 / 대본 을 채우고, 이미지 번호·등장인물·프롬프트·켄번즈
열은 비워 둔다 (그 네 열은 build_image_xlsx.py 가 채운다).

타임코드 계산 규칙 (검증됨):
  - 클립 길이 = 그 클립 words[*].duration 의 합
  - 클립 시작 = 앞선 클립 길이의 누적합 (첫 클립은 0)
  - words[*].originalStartTime 은 원본 미디어 기준이라 편집 후 타임라인과 어긋난다. 쓰지 않는다.
대본 텍스트 규칙:
  - captions[0].text[*].insert 를 이어 붙이고 앞뒤 공백/줄바꿈을 제거
  - 자막이 비어 있으면 type==0 인 단어 텍스트를 공백으로 이어 붙여 대체

사용:
  python vrew_to_storyboard.py <파일.vrew> [-o 출력.xlsx] [--clips-txt 클립목록.txt] [--quiet]
기본 출력: 같은 폴더의 <이름>_스토리보드.xlsx, <이름>_클립목록.txt
표준 출력에도 클립 목록(클립번호|시작시간|끝시간|대본)을 찍는다 — 엑셀은 이진 파일이라
모델이 바로 읽기 어렵기 때문이다.
"""
import argparse
import json
import sys
import zipfile
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

HEADERS = ["클립번호", "시작시간", "끝시간", "대본", "이미지 번호", "등장인물", "프롬프트", "켄번즈"]
COL_WIDTHS = {"A": 10, "B": 18, "C": 13, "D": 50, "E": 12, "F": 25, "G": 80, "H": 15}
HEADER_FILL = "4472C4"


def to_timecode(seconds: float) -> str:
    """초(float) → HH:MM:SS,mmm. 밀리초 단위로 먼저 반올림해 누적 오차를 막는다."""
    ms = int(round(seconds * 1000))
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, mm = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{mm:03d}"


def load_project(vrew_path: Path) -> dict:
    with zipfile.ZipFile(vrew_path) as zf:
        names = zf.namelist()
        target = "project.json" if "project.json" in names else next(
            (n for n in names if n.endswith("project.json")), None)
        if target is None:
            raise SystemExit(f"project.json 이 없습니다: {vrew_path}")
        with zf.open(target) as f:
            return json.load(f)


def caption_text(clip: dict) -> str:
    caps = clip.get("captions") or []
    if caps:
        ops = caps[0].get("text") or []
        text = "".join(op.get("insert", "") for op in ops if isinstance(op, dict))
        text = " ".join(text.split())  # 줄바꿈·연속 공백 정리
        if text:
            return text
    words = [w.get("text", "") for w in clip.get("words", []) if w.get("type", 0) == 0]
    return " ".join(t for t in words if t).strip()


def extract_clips(project: dict) -> list[dict]:
    clips = project.get("transcript", {}).get("clips", [])
    rows = []
    t = 0.0
    for i, clip in enumerate(clips, start=1):
        dur = sum(float(w.get("duration", 0) or 0) for w in clip.get("words", []))
        start, end = t, t + dur
        t = end
        rows.append({
            "no": i,
            "start": to_timecode(start),
            "end": to_timecode(end),
            "text": caption_text(clip),
            "seconds": dur,
        })
    return rows


def write_xlsx(rows: list[dict], out_path: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "스토리보드"
    ws.append(HEADERS)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=HEADER_FILL)
        cell.alignment = Alignment(horizontal="center")
    for r in rows:
        ws.append([r["no"], r["start"], r["end"], r["text"], None, None, None, None])
    for col, width in COL_WIDTHS.items():
        ws.column_dimensions[col].width = width
    wb.save(out_path)


def main() -> None:
    ap = argparse.ArgumentParser(description="Vrew → 스토리보드 xlsx")
    ap.add_argument("vrew", help=".vrew 파일 경로")
    ap.add_argument("-o", "--output", help="출력 xlsx 경로 (기본: <이름>_스토리보드.xlsx)")
    ap.add_argument("--clips-txt", help="클립 목록 txt 경로 (기본: <이름>_클립목록.txt). 'none' 이면 만들지 않음")
    ap.add_argument("--quiet", action="store_true", help="표준 출력에 클립 목록을 찍지 않음")
    args = ap.parse_args()

    vrew_path = Path(args.vrew)
    if not vrew_path.exists():
        raise SystemExit(f"파일이 없습니다: {vrew_path}")

    out_xlsx = Path(args.output) if args.output else vrew_path.with_name(vrew_path.stem + "_스토리보드.xlsx")
    rows = extract_clips(load_project(vrew_path))
    if not rows:
        raise SystemExit("클립이 하나도 없습니다.")
    write_xlsx(rows, out_xlsx)

    lines = ["클립번호|시작시간|끝시간|대본"] + [f"{r['no']}|{r['start']}|{r['end']}|{r['text']}" for r in rows]
    if args.clips_txt != "none":
        clips_txt = Path(args.clips_txt) if args.clips_txt else vrew_path.with_name(vrew_path.stem + "_클립목록.txt")
        clips_txt.write_text("\n".join(lines) + "\n", encoding="utf-8")
    else:
        clips_txt = None

    total = sum(r["seconds"] for r in rows)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(f"[완료] {out_xlsx}  (클립 {len(rows)}개, 총 길이 {to_timecode(total)})")
    if clips_txt:
        print(f"[클립목록] {clips_txt}")
    if not args.quiet:
        print("\n".join(lines))


if __name__ == "__main__":
    main()
