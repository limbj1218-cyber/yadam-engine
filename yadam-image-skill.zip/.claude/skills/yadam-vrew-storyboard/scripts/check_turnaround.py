#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
캐릭터 턴어라운드 시트(txt) 검사기.

시트 파일은 "Character turnaround reference sheet" 로 시작하는 블록이 인물 수만큼
이어진 텍스트다. 블록마다 지침 §6 의 필수 요소가 들어 있는지, 금지 표현이 없는지 본다.
--blocks <블록.txt> 를 주면 이미지용 블록 파일의 등장인물 태그와 시트의 SUBJECT 태그를
맞대어 본다 (시트에만 있거나 블록에만 있는 이름을 알려 준다).

사용:
  python check_turnaround.py <턴어라운드시트.txt> [--blocks 블록.txt]
오류가 있으면 종료 코드 1.
"""
import argparse
import re
import sys
from pathlib import Path

DECL = "Character turnaround reference sheet"
REQUIRED_LINES = [
    ("일관성 지시", "Use the ATTACHED character design as the EXACT identity"),
    ("SUBJECT", "SUBJECT —"),
    ("Hair", "- Hair:"),
    ("Outfit", "- Outfit:"),
    ("LAYOUT", "LAYOUT — full-body, the SAME character repeated in FOUR views in ONE row"),
    ("4면 지정", "1) FRONT view  2) 3/4 view  3) SIDE profile (90°)  4) BACK view"),
    ("STYLE", "STYLE: soft anime illustration, clean line, flat gentle shading."),
    ("STRICT RULES", "STRICT RULES:"),
    ("흰 배경", "- PLAIN PURE WHITE background, nothing else"),
    ("텍스트 금지", "- NO text, NO labels, NO names, NO color swatches, NO grid lines, NO captions"),
    ("폐쇄형 신발", "- Footwear must be CLOSED shoes that fully cover the foot and toes"),
    ("NOT sandals", "- NOT sandals, NOT flip-flops, NOT slippers, NOT open-toe footwear, NOT modern shoes"),
]
FORBIDDEN = {
    "얼굴색/피부색": r"\b(pale (face|skin|complexion)|fair skin|rosy cheeks|flushed|blushing|ashen|reddened|ruddy)\b",
    "유혈/부상": r"\b(blood|bleeding|wound|bruise|scar|injury)\b",
    "기술 키워드": r"\b(8k|4k|hdr|realistic|photorealistic)\b",
}
GROUP_TAGS = {"villagers", "crowd", "soldiers", "servants", "ministers", "guards", "people", "officials"}


def split_blocks(text: str) -> list[str]:
    idx = [m.start() for m in re.finditer(re.escape(DECL), text)]
    if not idx:
        return []
    idx.append(len(text))
    return [text[idx[i]:idx[i + 1]] for i in range(len(idx) - 1)]


def subject_tag(block: str) -> str | None:
    m = re.search(r"SUBJECT\s*—\s*([^,\n]+),", block)
    return m.group(1).strip() if m else None


def check_block(block: str, n: int) -> list[str]:
    errs = []
    tag = subject_tag(block) or f"블록{n}"
    head = f"[{tag}]"
    for label, needle in REQUIRED_LINES:
        if needle not in block:
            errs.append(f"{head} 필수 줄 누락({label}): {needle}")
    if subject_tag(block) is None:
        errs.append(f"{head} SUBJECT — <태그>, ... 형식을 찾지 못했습니다.")
    elif " " in tag:
        errs.append(f"{head} 태그에 공백이 있습니다 → 언더바(_)로 바꾸세요.")
    low = block.lower()
    # sandals 는 'NOT sandals' 줄에서만 허용
    if "sandal" in low.replace("not sandals", ""):
        errs.append(f"{head} 'sandals' 가 STRICT RULES 의 NOT 줄 밖에서 쓰였습니다.")
    if "jipsin" in low and "closed woven straw jipsin shoes" not in low:
        errs.append(f"{head} 짚신은 'closed woven straw jipsin shoes' 표기를 써야 합니다.")
    if "taesahye" in low and "upturned toes" not in low:
        errs.append(f"{head} 태사혜는 'with upturned toes' 를 함께 써야 합니다.")
    outfit = re.search(r"- Outfit:(.*)", block)
    if outfit and not re.search(r"\b(shoes|boots)\b", outfit.group(1).lower()):
        errs.append(f"{head} Outfit 줄에 신발 묘사(shoes/boots)가 없습니다.")
    if "- NOT royal" not in block and "NOT royal garments" not in block and "NOT court" not in block:
        errs.append(f"{head} 궁중 의상 금지 줄(NOT royal garments ...)이 없습니다. 왕족 인물이라 허용한 경우만 예외.")
    for label, rx in FORBIDDEN.items():
        m = re.search(rx, low)
        if m:
            errs.append(f"{head} 금지 표현({label}): '{m.group(0)}'")
    return errs


def block_tags(path: Path) -> set[str]:
    tags = set()
    with path.open(encoding="utf-8-sig") as f:
        for ln, raw in enumerate(f, start=1):
            line = raw.strip()
            if not line or (ln == 1 and line.startswith("이미지번호")):
                continue
            parts = line.split("|")
            if len(parts) == 6:
                tags.update(c.strip() for c in parts[3].split(",") if c.strip())
    return tags


def main() -> None:
    ap = argparse.ArgumentParser(description="턴어라운드 시트 검사")
    ap.add_argument("sheet", help="턴어라운드시트 txt")
    ap.add_argument("--blocks", help="이미지용 블록 txt (등장인물 대조)")
    args = ap.parse_args()
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    text = Path(args.sheet).read_text(encoding="utf-8-sig")
    blocks = split_blocks(text)
    errors = []
    if not blocks:
        errors.append(f"'{DECL}' 로 시작하는 블록이 없습니다.")
    for i, b in enumerate(blocks, start=1):
        errors.extend(check_block(b, i))
    tags = {t for t in (subject_tag(b) for b in blocks) if t}

    if args.blocks:
        used = block_tags(Path(args.blocks))
        named = {t for t in used if t.lower() not in GROUP_TAGS}
        missing = sorted(named - tags)
        extra = sorted(tags - used)
        if missing:
            errors.append(f"이미지용 블록에 나오지만 시트에 없는 인물: {', '.join(missing)}")
        if extra:
            print(f"참고: 시트에는 있지만 블록 등장인물 태그로는 안 쓰인 이름: {', '.join(extra)} (무리 대표 인물이면 괜찮음)")

    for e in errors:
        print("오류:", e)
    print(f"[검사] 인물 {len(blocks)}명 ({', '.join(sorted(tags))}), 오류 {len(errors)}건")
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
